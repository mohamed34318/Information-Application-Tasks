package com.example.task1;

public interface DataManager {
    String loadData();
    String processInput(String input);
}
