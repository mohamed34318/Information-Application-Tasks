package com.example.task1;


public interface MainPresenter {
    void loadData();
    void processInput(String input);
    void onDestroy();
}
