package com.example.task1;

public interface MainView {
    void showData(String data);
    void showError(String message);
}
