package com.example.task1;

public class DataManagerImpl implements DataManager {
    @Override
    public String loadData() {
        // Simulate loading data from a data source
        return "Initial Data";
    }

    @Override
    public String processInput(String input) {
        // Process the input data (echo back in this case)
        return input;
    }
}
