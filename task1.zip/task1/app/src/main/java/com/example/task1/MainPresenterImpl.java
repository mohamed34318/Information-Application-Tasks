package com.example.task1;

public class MainPresenterImpl implements MainPresenter {
    private MainView view;
    private DataManager dataManager;

    public MainPresenterImpl(MainView view, DataManager dataManager) {
        this.view = view;
        this.dataManager = dataManager;
    }

    @Override
    public void loadData() {
        // Load data from dataManager and display it in the view
        String data = dataManager.loadData();
        view.showData(data);
    }

    @Override
    public void processInput(String input) {
        // Process the input data and update the view accordingly
        String processedData = dataManager.processInput(input);
        view.showData(processedData);
    }

    @Override
    public void onDestroy() {
        // Clean up resources if needed
    }
}
